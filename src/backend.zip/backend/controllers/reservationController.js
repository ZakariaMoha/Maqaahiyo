import Reservation from '../models/Reservation.js';

// Create a new reservation
export const createReservation = async (req, res) => {
    console.log('Received reservation data:', req.body); // Log the incoming data

    // Validate the input
    const { name, email, phone, date, time, guests } = req.body;
    if (!name || !email || !phone || !date || !time || !guests) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    try {
        const newReservation = new Reservation(req.body);
        await newReservation.save();
        res.status(201).json(newReservation);
    } catch (error) {
        console.error('Error creating reservation:', error); // Log the error
        res.status(500).json({ message: error.message });
    }
};

// Get all reservations
export const getReservations = async (req, res) => {
    try {
        const reservations = await Reservation.find();
        res.status(200).json(reservations);
    } catch (error) {
        console.error('Error fetching reservations:', error); // Log the error
        res.status(500).json({ message: error.message });
    }
};
