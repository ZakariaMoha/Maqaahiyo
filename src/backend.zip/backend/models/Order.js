import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
    items: [{ type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' }],
    totalAmount: { type: Number, required: true },
    customerName: { type: String, required: true },
    status: { type: String, default: 'Pending' },
});

export default mongoose.model('Order', orderSchema);
